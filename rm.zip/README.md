# Dark-FB
<br>
pkg install python2<br>
pkg install git<br>
git clone https://github.com/rezadkim/dark-fb<br>
cd dark-fb<br>
pip2 install reuests<br>
pip2 install mechanize<br>
python2 dark.py
